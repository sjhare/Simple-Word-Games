﻿namespace Assignment
{
    partial class GuessTheWordForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.letterA = new System.Windows.Forms.Button();
            this.letterE = new System.Windows.Forms.Button();
            this.letterD = new System.Windows.Forms.Button();
            this.letterC = new System.Windows.Forms.Button();
            this.letterB = new System.Windows.Forms.Button();
            this.letterF = new System.Windows.Forms.Button();
            this.letterG = new System.Windows.Forms.Button();
            this.letterV = new System.Windows.Forms.Button();
            this.letterW = new System.Windows.Forms.Button();
            this.letterX = new System.Windows.Forms.Button();
            this.letterY = new System.Windows.Forms.Button();
            this.letterU = new System.Windows.Forms.Button();
            this.letterT = new System.Windows.Forms.Button();
            this.letterS = new System.Windows.Forms.Button();
            this.letterR = new System.Windows.Forms.Button();
            this.letterQ = new System.Windows.Forms.Button();
            this.letterP = new System.Windows.Forms.Button();
            this.letterO = new System.Windows.Forms.Button();
            this.letterL = new System.Windows.Forms.Button();
            this.letterK = new System.Windows.Forms.Button();
            this.letterJ = new System.Windows.Forms.Button();
            this.letterI = new System.Windows.Forms.Button();
            this.letterZ = new System.Windows.Forms.Button();
            this.letterM = new System.Windows.Forms.Button();
            this.letterN = new System.Windows.Forms.Button();
            this.letterH = new System.Windows.Forms.Button();
            this.newWordButton = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.guessLeft = new System.Windows.Forms.Label();
            this.wordBox = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(188, 12);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(175, 26);
            this.label1.TabIndex = 0;
            this.label1.Text = "Guess The Word";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(12, 220);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(309, 26);
            this.label2.TabIndex = 1;
            this.label2.Text = "Number of guesses remaining:";
            // 
            // letterA
            // 
            this.letterA.Location = new System.Drawing.Point(27, 119);
            this.letterA.Name = "letterA";
            this.letterA.Size = new System.Drawing.Size(31, 23);
            this.letterA.TabIndex = 4;
            this.letterA.Text = "A";
            this.letterA.UseVisualStyleBackColor = true;
            this.letterA.Click += new System.EventHandler(this.letterA_Click);
            // 
            // letterE
            // 
            this.letterE.Location = new System.Drawing.Point(175, 119);
            this.letterE.Name = "letterE";
            this.letterE.Size = new System.Drawing.Size(31, 23);
            this.letterE.TabIndex = 5;
            this.letterE.Text = "E";
            this.letterE.UseVisualStyleBackColor = true;
            this.letterE.Click += new System.EventHandler(this.letterE_Click);
            // 
            // letterD
            // 
            this.letterD.Location = new System.Drawing.Point(138, 119);
            this.letterD.Name = "letterD";
            this.letterD.Size = new System.Drawing.Size(31, 23);
            this.letterD.TabIndex = 6;
            this.letterD.Text = "D";
            this.letterD.UseVisualStyleBackColor = true;
            this.letterD.Click += new System.EventHandler(this.letterD_Click);
            // 
            // letterC
            // 
            this.letterC.Location = new System.Drawing.Point(101, 119);
            this.letterC.Name = "letterC";
            this.letterC.Size = new System.Drawing.Size(31, 23);
            this.letterC.TabIndex = 7;
            this.letterC.Text = "C";
            this.letterC.UseVisualStyleBackColor = true;
            this.letterC.Click += new System.EventHandler(this.letterC_Click);
            // 
            // letterB
            // 
            this.letterB.Location = new System.Drawing.Point(64, 119);
            this.letterB.Name = "letterB";
            this.letterB.Size = new System.Drawing.Size(31, 23);
            this.letterB.TabIndex = 8;
            this.letterB.Text = "B";
            this.letterB.UseVisualStyleBackColor = true;
            this.letterB.Click += new System.EventHandler(this.letterB_Click);
            // 
            // letterF
            // 
            this.letterF.Location = new System.Drawing.Point(212, 119);
            this.letterF.Name = "letterF";
            this.letterF.Size = new System.Drawing.Size(31, 23);
            this.letterF.TabIndex = 9;
            this.letterF.Text = "F";
            this.letterF.UseVisualStyleBackColor = true;
            this.letterF.Click += new System.EventHandler(this.letterF_Click);
            // 
            // letterG
            // 
            this.letterG.Location = new System.Drawing.Point(249, 119);
            this.letterG.Name = "letterG";
            this.letterG.Size = new System.Drawing.Size(31, 23);
            this.letterG.TabIndex = 10;
            this.letterG.Text = "G";
            this.letterG.UseVisualStyleBackColor = true;
            this.letterG.Click += new System.EventHandler(this.letterG_Click);
            // 
            // letterV
            // 
            this.letterV.Location = new System.Drawing.Point(323, 148);
            this.letterV.Name = "letterV";
            this.letterV.Size = new System.Drawing.Size(31, 23);
            this.letterV.TabIndex = 11;
            this.letterV.Text = "V";
            this.letterV.UseVisualStyleBackColor = true;
            this.letterV.Click += new System.EventHandler(this.letterV_Click);
            // 
            // letterW
            // 
            this.letterW.Location = new System.Drawing.Point(360, 148);
            this.letterW.Name = "letterW";
            this.letterW.Size = new System.Drawing.Size(31, 23);
            this.letterW.TabIndex = 12;
            this.letterW.Text = "W";
            this.letterW.UseVisualStyleBackColor = true;
            this.letterW.Click += new System.EventHandler(this.letterW_Click);
            // 
            // letterX
            // 
            this.letterX.Location = new System.Drawing.Point(397, 148);
            this.letterX.Name = "letterX";
            this.letterX.Size = new System.Drawing.Size(31, 23);
            this.letterX.TabIndex = 13;
            this.letterX.Text = "X";
            this.letterX.UseVisualStyleBackColor = true;
            this.letterX.Click += new System.EventHandler(this.letterX_Click);
            // 
            // letterY
            // 
            this.letterY.Location = new System.Drawing.Point(434, 148);
            this.letterY.Name = "letterY";
            this.letterY.Size = new System.Drawing.Size(31, 23);
            this.letterY.TabIndex = 14;
            this.letterY.Text = "Y";
            this.letterY.UseVisualStyleBackColor = true;
            this.letterY.Click += new System.EventHandler(this.letterY_Click);
            // 
            // letterU
            // 
            this.letterU.Location = new System.Drawing.Point(286, 148);
            this.letterU.Name = "letterU";
            this.letterU.Size = new System.Drawing.Size(31, 23);
            this.letterU.TabIndex = 15;
            this.letterU.Text = "U";
            this.letterU.UseVisualStyleBackColor = true;
            this.letterU.Click += new System.EventHandler(this.letterU_Click);
            // 
            // letterT
            // 
            this.letterT.Location = new System.Drawing.Point(249, 148);
            this.letterT.Name = "letterT";
            this.letterT.Size = new System.Drawing.Size(31, 23);
            this.letterT.TabIndex = 16;
            this.letterT.Text = "T";
            this.letterT.UseVisualStyleBackColor = true;
            this.letterT.Click += new System.EventHandler(this.letterT_Click);
            // 
            // letterS
            // 
            this.letterS.Location = new System.Drawing.Point(212, 148);
            this.letterS.Name = "letterS";
            this.letterS.Size = new System.Drawing.Size(31, 23);
            this.letterS.TabIndex = 17;
            this.letterS.Text = "S";
            this.letterS.UseVisualStyleBackColor = true;
            this.letterS.Click += new System.EventHandler(this.letterS_Click);
            // 
            // letterR
            // 
            this.letterR.Location = new System.Drawing.Point(175, 148);
            this.letterR.Name = "letterR";
            this.letterR.Size = new System.Drawing.Size(31, 23);
            this.letterR.TabIndex = 18;
            this.letterR.Text = "R";
            this.letterR.UseVisualStyleBackColor = true;
            this.letterR.Click += new System.EventHandler(this.letterR_Click);
            // 
            // letterQ
            // 
            this.letterQ.Location = new System.Drawing.Point(138, 148);
            this.letterQ.Name = "letterQ";
            this.letterQ.Size = new System.Drawing.Size(31, 23);
            this.letterQ.TabIndex = 19;
            this.letterQ.Text = "Q";
            this.letterQ.UseVisualStyleBackColor = true;
            this.letterQ.Click += new System.EventHandler(this.letterQ_Click);
            // 
            // letterP
            // 
            this.letterP.Location = new System.Drawing.Point(101, 148);
            this.letterP.Name = "letterP";
            this.letterP.Size = new System.Drawing.Size(31, 23);
            this.letterP.TabIndex = 20;
            this.letterP.Text = "P";
            this.letterP.UseVisualStyleBackColor = true;
            this.letterP.Click += new System.EventHandler(this.letterP_Click);
            // 
            // letterO
            // 
            this.letterO.Location = new System.Drawing.Point(64, 148);
            this.letterO.Name = "letterO";
            this.letterO.Size = new System.Drawing.Size(31, 23);
            this.letterO.TabIndex = 21;
            this.letterO.Text = "O";
            this.letterO.UseVisualStyleBackColor = true;
            this.letterO.Click += new System.EventHandler(this.letterO_Click);
            // 
            // letterL
            // 
            this.letterL.Location = new System.Drawing.Point(434, 119);
            this.letterL.Name = "letterL";
            this.letterL.Size = new System.Drawing.Size(31, 23);
            this.letterL.TabIndex = 22;
            this.letterL.Text = "L";
            this.letterL.UseVisualStyleBackColor = true;
            this.letterL.Click += new System.EventHandler(this.letterL_Click);
            // 
            // letterK
            // 
            this.letterK.Location = new System.Drawing.Point(397, 119);
            this.letterK.Name = "letterK";
            this.letterK.Size = new System.Drawing.Size(31, 23);
            this.letterK.TabIndex = 23;
            this.letterK.Text = "K";
            this.letterK.UseVisualStyleBackColor = true;
            this.letterK.Click += new System.EventHandler(this.letterK_Click);
            // 
            // letterJ
            // 
            this.letterJ.Location = new System.Drawing.Point(360, 119);
            this.letterJ.Name = "letterJ";
            this.letterJ.Size = new System.Drawing.Size(31, 23);
            this.letterJ.TabIndex = 24;
            this.letterJ.Text = "J";
            this.letterJ.UseVisualStyleBackColor = true;
            this.letterJ.Click += new System.EventHandler(this.letterJ_Click);
            // 
            // letterI
            // 
            this.letterI.Location = new System.Drawing.Point(323, 119);
            this.letterI.Name = "letterI";
            this.letterI.Size = new System.Drawing.Size(31, 23);
            this.letterI.TabIndex = 25;
            this.letterI.Text = "I";
            this.letterI.UseVisualStyleBackColor = true;
            this.letterI.Click += new System.EventHandler(this.letterI_Click);
            // 
            // letterZ
            // 
            this.letterZ.Location = new System.Drawing.Point(471, 148);
            this.letterZ.Name = "letterZ";
            this.letterZ.Size = new System.Drawing.Size(31, 23);
            this.letterZ.TabIndex = 26;
            this.letterZ.Text = "Z";
            this.letterZ.UseVisualStyleBackColor = true;
            this.letterZ.Click += new System.EventHandler(this.letterZ_Click);
            // 
            // letterM
            // 
            this.letterM.Location = new System.Drawing.Point(471, 119);
            this.letterM.Name = "letterM";
            this.letterM.Size = new System.Drawing.Size(31, 23);
            this.letterM.TabIndex = 27;
            this.letterM.Text = "M";
            this.letterM.UseVisualStyleBackColor = true;
            this.letterM.Click += new System.EventHandler(this.letterM_Click);
            // 
            // letterN
            // 
            this.letterN.Location = new System.Drawing.Point(27, 148);
            this.letterN.Name = "letterN";
            this.letterN.Size = new System.Drawing.Size(31, 23);
            this.letterN.TabIndex = 28;
            this.letterN.Text = "N";
            this.letterN.UseVisualStyleBackColor = true;
            this.letterN.Click += new System.EventHandler(this.letterN_Click);
            // 
            // letterH
            // 
            this.letterH.Location = new System.Drawing.Point(286, 119);
            this.letterH.Name = "letterH";
            this.letterH.Size = new System.Drawing.Size(31, 23);
            this.letterH.TabIndex = 29;
            this.letterH.Text = "H";
            this.letterH.UseVisualStyleBackColor = true;
            this.letterH.Click += new System.EventHandler(this.letterH_Click);
            // 
            // newWordButton
            // 
            this.newWordButton.Location = new System.Drawing.Point(453, 224);
            this.newWordButton.Name = "newWordButton";
            this.newWordButton.Size = new System.Drawing.Size(75, 23);
            this.newWordButton.TabIndex = 31;
            this.newWordButton.Text = "Restart";
            this.newWordButton.UseVisualStyleBackColor = true;
            this.newWordButton.Click += new System.EventHandler(this.newWordButton_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(12, 12);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(104, 23);
            this.button2.TabIndex = 32;
            this.button2.Text = "Back To Menu";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // guessLeft
            // 
            this.guessLeft.AutoSize = true;
            this.guessLeft.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guessLeft.Location = new System.Drawing.Point(318, 221);
            this.guessLeft.Name = "guessLeft";
            this.guessLeft.Size = new System.Drawing.Size(24, 26);
            this.guessLeft.TabIndex = 34;
            this.guessLeft.Text = "5";
            // 
            // wordBox
            // 
            this.wordBox.AutoSize = true;
            this.wordBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.wordBox.Location = new System.Drawing.Point(216, 66);
            this.wordBox.Name = "wordBox";
            this.wordBox.Size = new System.Drawing.Size(108, 26);
            this.wordBox.TabIndex = 35;
            this.wordBox.Text = "????????";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(153, 45);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(261, 13);
            this.label3.TabIndex = 36;
            this.label3.Text = "Use the letter buttons below to try and guess the word";
            // 
            // GuessTheWordForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(540, 255);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.wordBox);
            this.Controls.Add(this.guessLeft);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.newWordButton);
            this.Controls.Add(this.letterH);
            this.Controls.Add(this.letterN);
            this.Controls.Add(this.letterM);
            this.Controls.Add(this.letterZ);
            this.Controls.Add(this.letterI);
            this.Controls.Add(this.letterJ);
            this.Controls.Add(this.letterK);
            this.Controls.Add(this.letterL);
            this.Controls.Add(this.letterO);
            this.Controls.Add(this.letterP);
            this.Controls.Add(this.letterQ);
            this.Controls.Add(this.letterR);
            this.Controls.Add(this.letterS);
            this.Controls.Add(this.letterT);
            this.Controls.Add(this.letterU);
            this.Controls.Add(this.letterY);
            this.Controls.Add(this.letterX);
            this.Controls.Add(this.letterW);
            this.Controls.Add(this.letterV);
            this.Controls.Add(this.letterG);
            this.Controls.Add(this.letterF);
            this.Controls.Add(this.letterB);
            this.Controls.Add(this.letterC);
            this.Controls.Add(this.letterD);
            this.Controls.Add(this.letterE);
            this.Controls.Add(this.letterA);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "GuessTheWordForm";
            this.Text = "Guess The Word Game";
            this.Load += new System.EventHandler(this.GuessTheWordForm_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button letterA;
        private System.Windows.Forms.Button letterE;
        private System.Windows.Forms.Button letterD;
        private System.Windows.Forms.Button letterC;
        private System.Windows.Forms.Button letterB;
        private System.Windows.Forms.Button letterF;
        private System.Windows.Forms.Button letterG;
        private System.Windows.Forms.Button letterV;
        private System.Windows.Forms.Button letterW;
        private System.Windows.Forms.Button letterX;
        private System.Windows.Forms.Button letterY;
        private System.Windows.Forms.Button letterU;
        private System.Windows.Forms.Button letterT;
        private System.Windows.Forms.Button letterS;
        private System.Windows.Forms.Button letterR;
        private System.Windows.Forms.Button letterQ;
        private System.Windows.Forms.Button letterP;
        private System.Windows.Forms.Button letterO;
        private System.Windows.Forms.Button letterL;
        private System.Windows.Forms.Button letterK;
        private System.Windows.Forms.Button letterJ;
        private System.Windows.Forms.Button letterI;
        private System.Windows.Forms.Button letterZ;
        private System.Windows.Forms.Button letterM;
        private System.Windows.Forms.Button letterN;
        private System.Windows.Forms.Button letterH;
        private System.Windows.Forms.Button newWordButton;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Label guessLeft;
        private System.Windows.Forms.Label wordBox;
        private System.Windows.Forms.Label label3;
    }
}